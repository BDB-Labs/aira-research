"""
adjudication_kappa.py
---------------------
Reads a completed rater_sheet.csv and computes:

  - Per-check Cohen's kappa (precision adjudication)
  - Overall Cohen's kappa
  - Per-check false-positive rate  (rater says INVALID, AIRA said FAIL)
  - Per-check false-negative rate  (rater says MISSED, AIRA said nothing)
  - Publication-ready LaTeX table

Usage:
  python adjudication_kappa.py --sheet adjudication/rater_sheet.csv
  python adjudication_kappa.py --sheet adjudication/rater_sheet.csv --latex
"""

import argparse
import csv
import math
from collections import defaultdict
from pathlib import Path

# ── Kappa calculation ─────────────────────────────────────────────────────────

def cohen_kappa(r1: list[str], r2: list[str]) -> float:
    """
    Compute Cohen's kappa for two lists of binary ratings.
    Ratings are normalised to TRUE/FALSE; PARTIAL counts as TRUE.
    Returns kappa, or NaN if insufficient data.
    """
    assert len(r1) == len(r2), "Rating lists must be the same length"
    n = len(r1)
    if n == 0:
        return float("nan")

    def norm(v: str) -> int:
        v = v.strip().upper()
        if v in ("TRUE", "T", "YES", "Y", "1", "VALID", "PARTIAL"):
            return 1
        return 0

    r1n = [norm(v) for v in r1]
    r2n = [norm(v) for v in r2]

    agree = sum(a == b for a, b in zip(r1n, r2n))
    po = agree / n

    p1_yes = sum(r1n) / n
    p2_yes = sum(r2n) / n
    pe = (p1_yes * p2_yes) + ((1 - p1_yes) * (1 - p2_yes))

    if pe == 1.0:
        return float("nan")

    return (po - pe) / (1 - pe)

def kappa_interpretation(k: float) -> str:
    if math.isnan(k):   return "—"
    if k < 0.00:        return "poor"
    if k < 0.20:        return "slight"
    if k < 0.40:        return "fair"
    if k < 0.60:        return "moderate"
    if k < 0.80:        return "substantial"
    return "almost perfect"

# ── Load completed sheet ──────────────────────────────────────────────────────

def load_sheet(path: str) -> list[dict]:
    rows = []
    with open(path) as fh:
        for row in csv.DictReader(fh):
            rows.append(row)
    return rows

# ── Analysis ──────────────────────────────────────────────────────────────────

TARGET_CHECKS = [
    "exception_handling",
    "environment_safety",
    "startup_integrity",
    "background_tasks",
    "fallback_control",
    "return_contracts",
    "confidence_representation",
]

def analyse(rows: list[dict]) -> dict:
    """
    Returns a dict with per-check and overall statistics.
    """
    # Separate finding rows (AIRA fired) from null rows (AIRA silent)
    finding_rows = [r for r in rows if r.get("aira_checks_failed", "0") != "0"]
    null_rows    = [r for r in rows if r.get("aira_checks_failed", "0") == "0"]

    results = {}

    # --- Per-check precision (finding rows only, filtered to that check) ---
    for check in TARGET_CHECKS:
        check_rows = [
            r for r in finding_rows
            if check in r.get("aira_failed_check_ids", "")
        ]
        r1 = [r.get("rater1_finding_valid", "") for r in check_rows]
        r2 = [r.get("rater2_finding_valid", "") for r in check_rows]

        # Only compute kappa where both raters have filled in a value
        paired = [(a, b) for a, b in zip(r1, r2) if a.strip() and b.strip()]
        if paired:
            k = cohen_kappa([p[0] for p in paired], [p[1] for p in paired])
        else:
            k = float("nan")

        # False-positive rate: rater1 says INVALID (precision from rater1 only
        # as primary rater when rater2 not yet available)
        r1_filled = [v for v in r1 if v.strip()]
        fp_count  = sum(
            1 for v in r1_filled
            if v.strip().upper() in ("FALSE", "F", "NO", "N", "0", "INVALID")
        )
        fp_rate = fp_count / len(r1_filled) if r1_filled else float("nan")

        results[check] = {
            "n_findings":   len(check_rows),
            "n_rated":      len(paired),
            "kappa":        k,
            "interp":       kappa_interpretation(k),
            "fp_rate":      fp_rate,
            "fp_count":     fp_count,
            "r1_filled":    len(r1_filled),
        }

    # --- False-negative rate from null rows ---
    missed_r1 = [r for r in null_rows if r.get("rater1_missed_finding", "").strip()]
    fn_rate   = len(missed_r1) / len(null_rows) if null_rows else float("nan")

    # --- Overall kappa (all finding rows, any check) ---
    all_r1 = [r.get("rater1_finding_valid", "") for r in finding_rows]
    all_r2 = [r.get("rater2_finding_valid", "") for r in finding_rows]
    all_paired = [(a, b) for a, b in zip(all_r1, all_r2) if a.strip() and b.strip()]
    if all_paired:
        overall_k = cohen_kappa([p[0] for p in all_paired], [p[1] for p in all_paired])
    else:
        overall_k = float("nan")

    results["_overall"] = {
        "n_findings":  len(finding_rows),
        "n_null":      len(null_rows),
        "n_rated":     len(all_paired),
        "kappa":       overall_k,
        "interp":      kappa_interpretation(overall_k),
        "fn_rate":     fn_rate,
        "fn_missed":   len(missed_r1),
        "fn_total":    len(null_rows),
    }

    return results

# ── Reporting ─────────────────────────────────────────────────────────────────

def print_report(results: dict) -> None:
    ov = results["_overall"]
    print("\n── Adjudication Results ──")
    print(f"  Overall κ : {ov['kappa']:.3f}  ({ov['interp']})")
    print(f"  Rated     : {ov['n_rated']} of {ov['n_findings']} finding rows")
    print(f"  False-neg : {ov['fn_missed']}/{ov['fn_total']} null files "
          f"had rater-identified missed findings  "
          f"(FN rate ≈ {ov['fn_rate']:.1%})")
    print()
    print(f"  {'Check':30s}  {'n':>5}  {'κ':>7}  {'interp':>16}  {'FP rate':>8}")
    print(f"  {'-'*30}  {'-'*5}  {'-'*7}  {'-'*16}  {'-'*8}")
    for check in TARGET_CHECKS:
        r = results[check]
        k_str = f"{r['kappa']:.3f}" if not math.isnan(r['kappa']) else "  —"
        fp_str = f"{r['fp_rate']:.1%}" if not math.isnan(r['fp_rate']) else "  —"
        print(f"  {check:30s}  {r['n_findings']:>5}  {k_str:>7}  "
              f"{r['interp']:>16}  {fp_str:>8}")

def latex_table(results: dict) -> str:
    ov = results["_overall"]
    lines = [
        r"\begin{table}[htbp]",
        r"\centering",
        r"\caption{Scanner Validation --- Inter-Rater Agreement and False-Positive Rates}",
        r"\label{tab:adjudication}",
        r"\small",
        r"\begin{tabular}{@{}lrrrr@{}}",
        r"\toprule",
        r"\textbf{Check} & \textbf{$n$} & \textbf{$\kappa$} & "
        r"\textbf{Agreement} & \textbf{FP rate} \\",
        r"\midrule",
    ]
    for check in TARGET_CHECKS:
        r = results[check]
        k_str  = f"{r['kappa']:.2f}" if not math.isnan(r['kappa']) else "---"
        fp_str = f"{r['fp_rate']:.0%}" if not math.isnan(r['fp_rate']) else "---"
        lines.append(
            rf"\checkid{{{check}}} & {r['n_findings']} & {k_str} & "
            rf"{r['interp']} & {fp_str} \\"
        )
    lines += [
        r"\midrule",
        rf"\textit{{Overall}} & {ov['n_findings']} & "
        rf"{ov['kappa']:.2f} & {ov['interp']} & --- \\",
        r"\midrule",
        rf"\multicolumn{{5}}{{@{{}}l@{{}}}}{{\small "
        rf"False-negative rate (recall sample, $n={ov['fn_total']}$): "
        rf"{ov['fn_rate']:.0%} ({ov['fn_missed']} rater-identified missed findings)}}  \\",
        r"\bottomrule",
        r"\end{tabular}",
        r"\end{table}",
    ]
    return "\n".join(lines)

# ── CLI ───────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Compute adjudication kappa statistics")
    parser.add_argument("--sheet",  default="adjudication/rater_sheet.csv")
    parser.add_argument("--latex",  action="store_true",
                        help="Print LaTeX table for paper")
    parser.add_argument("--out",    default=None,
                        help="Write LaTeX table to file")
    args = parser.parse_args()

    print(f"Loading {args.sheet}...")
    rows = load_sheet(args.sheet)
    print(f"  {len(rows)} rows loaded")

    # Check whether raters have filled anything in yet
    filled = sum(1 for r in rows if r.get("rater1_finding_valid", "").strip())
    if filled == 0:
        print("\n  No rater responses found yet.")
        print("  Fill in rater1_finding_valid (and rater2_finding_valid) columns")
        print("  in the Google Sheet, then re-run this script.")
        return

    results = analyse(rows)
    print_report(results)

    if args.latex or args.out:
        table = latex_table(results)
        if args.out:
            Path(args.out).write_text(table)
            print(f"\n  LaTeX table written to {args.out}")
        else:
            print("\n── LaTeX table ──\n")
            print(table)

if __name__ == "__main__":
    main()
