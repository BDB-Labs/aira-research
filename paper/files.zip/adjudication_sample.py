"""
adjudication_sample.py
----------------------
Draws the 100-file adjudication sample for AIRA Study 3 scanner validation.

Sampling design:
  - 7 target checks × 10 files each = 70 finding files
    - 5 from Arm A (AI-attributed), 5 from Arm B (human control) per check
  - 30 null files (AIRA found nothing) drawn across both arms and languages
  - Arm identity BLINDED in rater output (replaced with anonymous rater_id)
  - Sample is seeded and fully reproducible

Outputs:
  adjudication/sample_manifest.csv      — internal record with arm identity
  adjudication/rater_sheet.csv          — blinded sheet for raters (no arm column)
  adjudication/rater_instructions.md    — protocol document for raters

Usage:
  python adjudication_sample.py --findings data/file_results.csv --seed 42
"""

import argparse
import csv
import hashlib
import random
from pathlib import Path
from collections import defaultdict

# ── Config ────────────────────────────────────────────────────────────────────

TARGET_CHECKS = [
    "exception_handling",
    "environment_safety",
    "startup_integrity",
    "background_tasks",
    "fallback_control",
    "return_contracts",
    "confidence_representation",
]

FILES_PER_CHECK     = 10   # 5 per arm per check
FILES_PER_ARM_CHECK = 5
NULL_FILES          = 30   # AIRA found nothing — recall sample
OUTPUT_DIR          = Path("adjudication")

ARM_LABELS = {
    "agent_attributed": "A",
    "human_control":    "B",
}

# ── Load data ─────────────────────────────────────────────────────────────────

def load_findings(path: str) -> list[dict]:
    rows = []
    with open(path) as fh:
        for row in csv.DictReader(fh):
            row["checks_list"] = [
                c.strip() for c in row.get("failed_check_ids", "").split(",")
                if c.strip()
            ]
            rows.append(row)
    return rows

# ── Sampling ──────────────────────────────────────────────────────────────────

def draw_sample(rows: list[dict], seed: int) -> list[dict]:
    rng = random.Random(seed)

    # Index by (arm, check) for finding files
    by_arm_check: dict[tuple, list[dict]] = defaultdict(list)
    null_pool:    dict[str, list[dict]]   = defaultdict(list)  # arm -> rows

    for row in rows:
        arm = row["arm"]
        checks = row["checks_list"]
        if checks:
            for check in checks:
                if check in TARGET_CHECKS:
                    by_arm_check[(arm, check)].append(row)
        else:
            null_pool[arm].append(row)

    # Shuffle all pools
    for pool in by_arm_check.values():
        rng.shuffle(pool)
    for pool in null_pool.values():
        rng.shuffle(pool)

    selected: list[dict] = []
    seen_ids: set[str]   = set()

    def pick(pool, n, tag):
        taken = []
        for row in pool:
            if len(taken) >= n:
                break
            sid = row["sample_id"]
            if sid not in seen_ids:
                seen_ids.add(sid)
                taken.append({**row, "_draw_reason": tag})
        return taken

    # Finding files: 5 per arm per check
    for check in TARGET_CHECKS:
        for arm in ("agent_attributed", "human_control"):
            pool = by_arm_check.get((arm, check), [])
            draws = pick(pool, FILES_PER_ARM_CHECK, f"finding:{check}")
            if len(draws) < FILES_PER_ARM_CHECK:
                print(f"  WARNING: only {len(draws)}/{FILES_PER_ARM_CHECK} "
                      f"available for ({arm}, {check})")
            selected.extend(draws)

    # Null files: 15 per arm
    null_per_arm = NULL_FILES // 2
    for arm in ("agent_attributed", "human_control"):
        draws = pick(null_pool[arm], null_per_arm, "null")
        selected.extend(draws)

    return selected

# ── Blinding ──────────────────────────────────────────────────────────────────

def blind_id(sample_id: str, seed: int) -> str:
    """Generate a stable anonymous rater ID from sample_id."""
    h = hashlib.sha256(f"{seed}:{sample_id}".encode()).hexdigest()[:8]
    return f"FILE-{h.upper()}"

# ── Output writers ────────────────────────────────────────────────────────────

MANIFEST_FIELDS = [
    "rater_id", "arm", "arm_label", "sample_id", "repo_name",
    "language", "file_size_band", "file_line_count",
    "checks_failed", "failed_check_ids", "high", "medium", "low",
    "_draw_reason",
]

RATER_FIELDS = [
    "rater_id", "language", "file_size_band", "file_line_count",
    "aira_checks_failed", "aira_failed_check_ids",
    "aira_high", "aira_medium", "aira_low",
    # Rater fill columns:
    "rater1_finding_valid",        # TRUE / FALSE / PARTIAL per finding
    "rater1_missed_finding",       # check id if rater sees a miss AIRA skipped
    "rater1_notes",
    "rater2_finding_valid",
    "rater2_missed_finding",
    "rater2_notes",
]

def write_manifest(sample: list[dict], seed: int, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=MANIFEST_FIELDS, extrasaction="ignore")
        w.writeheader()
        for row in sample:
            w.writerow({
                "rater_id":       blind_id(row["sample_id"], seed),
                "arm":            row["arm"],
                "arm_label":      ARM_LABELS.get(row["arm"], "?"),
                "sample_id":      row["sample_id"],
                "repo_name":      row["repo_name"],
                "language":       row["language"],
                "file_size_band": row["file_size_band"],
                "file_line_count":row["file_line_count"],
                "checks_failed":  row["checks_failed"],
                "failed_check_ids": row.get("failed_check_ids", ""),
                "high":           row["high"],
                "medium":         row["medium"],
                "low":            row["low"],
                "_draw_reason":   row["_draw_reason"],
            })

def write_rater_sheet(sample: list[dict], seed: int, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=RATER_FIELDS, extrasaction="ignore")
        w.writeheader()
        for row in sample:
            w.writerow({
                "rater_id":             blind_id(row["sample_id"], seed),
                "language":             row["language"],
                "file_size_band":       row["file_size_band"],
                "file_line_count":      row["file_line_count"],
                "aira_checks_failed":   row["checks_failed"],
                "aira_failed_check_ids":row.get("failed_check_ids", ""),
                "aira_high":            row["high"],
                "aira_medium":          row["medium"],
                "aira_low":             row["low"],
                "rater1_finding_valid": "",
                "rater1_missed_finding":"",
                "rater1_notes":         "",
                "rater2_finding_valid": "",
                "rater2_missed_finding":"",
                "rater2_notes":         "",
            })

# ── Summary ───────────────────────────────────────────────────────────────────

def print_summary(sample: list[dict], seed: int) -> None:
    total = len(sample)
    finding = [r for r in sample if r["_draw_reason"].startswith("finding")]
    null    = [r for r in sample if r["_draw_reason"] == "null"]

    print(f"\n── Adjudication sample (seed={seed}) ──")
    print(f"  Total files : {total}")
    print(f"  Finding     : {len(finding)}  (AIRA fired on at least one target check)")
    print(f"  Null        : {len(null)}  (AIRA found nothing — recall sample)")
    print()
    print(f"  {'Check':30s}  {'Arm A':>6}  {'Arm B':>6}")
    for check in TARGET_CHECKS:
        a = sum(1 for r in finding
                if r["arm"] == "agent_attributed" and check in r.get("failed_check_ids",""))
        b = sum(1 for r in finding
                if r["arm"] == "human_control"    and check in r.get("failed_check_ids",""))
        print(f"  {check:30s}  {a:>6}  {b:>6}")
    print()
    print(f"  Null by arm:")
    for arm in ("agent_attributed", "human_control"):
        n = sum(1 for r in null if r["arm"] == arm)
        print(f"    {arm:20s}: {n}")

# ── CLI ───────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Draw AIRA adjudication sample")
    parser.add_argument("--findings", default="data/file_results.csv")
    parser.add_argument("--seed",     type=int, default=42)
    parser.add_argument("--out-dir",  default="adjudication")
    args = parser.parse_args()

    OUTPUT_DIR_resolved = Path(args.out_dir)

    print(f"Loading {args.findings}...")
    rows = load_findings(args.findings)
    print(f"  {len(rows)} file records loaded")

    print("Drawing stratified sample...")
    sample = draw_sample(rows, args.seed)

    print_summary(sample, args.seed)

    manifest_path = OUTPUT_DIR_resolved / "sample_manifest.csv"
    rater_path    = OUTPUT_DIR_resolved / "rater_sheet.csv"

    write_manifest(sample, args.seed, manifest_path)
    write_rater_sheet(sample, args.seed, rater_path)

    print(f"\n  Manifest (with arm identity): {manifest_path}")
    print(f"  Rater sheet (blinded)       : {rater_path}")
    print(f"\n  Upload rater_sheet.csv to Google Sheets.")
    print(f"  Keep sample_manifest.csv local — do not share with raters.")

if __name__ == "__main__":
    main()
