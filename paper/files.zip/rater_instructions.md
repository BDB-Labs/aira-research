# AIRA Scanner Adjudication Study — Rater Instructions

**Version:** 1.0  
**Study:** AIRA Study 3 Scanner Validation  
**Purpose:** To establish inter-rater reliability and precision/recall estimates
for the AIRA deterministic scanner, for inclusion in the published paper.

---

## What you are doing and why

AIRA is a static analysis scanner that applies 15 checks to source code files
to detect patterns associated with "failure truthfulness" violations — places
where code may silently conceal failure rather than surface it. Before the
scanner's findings can support published empirical claims, we need to know:

1. **Precision:** When AIRA flags a finding, is it correct? (Are the findings real?)
2. **Recall:** When AIRA is silent, is it missing real problems? (Are the non-findings trustworthy?)
3. **Reliability:** Do two independent reviewers agree on whether a finding is valid?

You will review 100 files. For each file, AIRA has recorded what it found (or
found nothing). Your job is to independently assess whether AIRA's judgment is correct.

**Important:** You do not know — and should not try to determine — whether a file
was written by a human or an AI coding tool. That information has been removed.
Judge only the code and the finding.

---

## The Google Sheet

Open the shared rater sheet. Each row is one file. The columns are:

| Column | What it contains |
|--------|-----------------|
| `rater_id` | Anonymous file identifier (FILE-xxxxxxxx) |
| `language` | JavaScript, Python, or TypeScript |
| `file_size_band` | Approximate file size range |
| `file_line_count` | Exact line count |
| `aira_checks_failed` | Number of checks AIRA flagged |
| `aira_failed_check_ids` | Which checks AIRA flagged (comma-separated) |
| `aira_high / medium / low` | Severity count of AIRA findings |
| `rater1_finding_valid` | **← YOU FILL THIS IN** |
| `rater1_missed_finding` | **← YOU FILL THIS IN (if applicable)** |
| `rater1_notes` | **← YOUR NOTES** |

Rater 2 fills in the `rater2_*` columns independently. Do not look at the
other rater's responses before completing your own.

---

## How to retrieve the file to review

Each row gives you the `rater_id` (e.g. `FILE-3A7F9B2C`). The study coordinator
will provide you with a link or local path to retrieve the actual file content
associated with each rater_id. Files are provided as:

- **Full file content** — the complete source file as it existed in the PR
- **Patch context** — the unified diff showing what changed in the PR

You may look at either or both. If the full file provides essential context that
the patch alone doesn't (e.g. to understand whether an exception handler is
intentionally broad or accidentally so), use the full file.

If you want additional context — the surrounding module, the function's callers,
the repo's error handling conventions — note this in `rater1_notes` and mark the
finding as `PARTIAL` rather than leaving it blank.

---

## The seven checks you will encounter

These are the checks AIRA fires most frequently. Read each definition carefully
before starting. The question is always: **does the code exhibit this pattern?**

### C03 — exception_handling
**Definition:** The code catches exceptions using broad catch clauses
(`except Exception`, `catch (e)`, `catch {}`) that suppress or swallow the
error rather than re-raising it, logging it meaningfully, or propagating it to
a caller who can handle it. The result is that runtime failures become invisible.

**VALID finding examples:**
- `except Exception: pass`
- `catch (e) { return null; }` with no logging
- `try { ... } catch {}` (empty catch block)

**INVALID finding examples:**
- `except Exception as e: logger.error(e); raise` (re-raises — not suppression)
- `except ValueError:` (specific exception type — not broad)

---

### C09 — environment_safety
**Definition:** The code reads an environment variable and uses the result
directly in a critical path (database connection, auth, API call) without
validating that it is non-null and non-empty. A missing environment variable
silently passes `None` or an empty string into a critical operation.

**VALID finding examples:**
- `db_url = os.environ.get("DATABASE_URL")` used directly in `connect(db_url)`
  with no null check
- `api_key = process.env.API_KEY` passed to an auth header with no guard

**INVALID finding examples:**
- `db_url = os.environ["DATABASE_URL"]` (KeyError on missing — not silent)
- `api_key = os.getenv("KEY", "")` with an `if not api_key: raise` guard below

---

### C10 — startup_integrity
**Definition:** The application starts (serves requests, begins processing)
without first validating that required configuration, credentials, or
dependencies are present and healthy. Misconfiguration is deferred to runtime
where it causes silent partial failure rather than a clean startup error.

**VALID finding examples:**
- A Flask/Express app that starts serving before checking DB connectivity
- A worker that begins consuming a queue before validating its config file

**INVALID finding examples:**
- A startup function that explicitly checks all required env vars and raises
  on failure before accepting any work

---

### C08 — background_tasks
**Definition:** The code schedules or fires a background task, coroutine, or
async operation where exceptions raised inside the task are not caught or
surfaced to the caller — they silently disappear.

**VALID finding examples:**
- `asyncio.create_task(some_coroutine())` with no error callback or
  `add_done_callback` that inspects the result
- `threading.Thread(target=fn).start()` with no exception handling in `fn`

**INVALID finding examples:**
- `asyncio.create_task(fn())` where `fn` has its own internal try/except
  that logs and re-raises
- Tasks with explicit `add_done_callback` that checks for exceptions

---

### C04 — fallback_control
**Definition:** The code uses a fallback value or default in a way that
silently masks a failure — the caller receives a "successful" result that is
actually a substituted default, with no signal that the original operation failed.

**VALID finding examples:**
- `result = fetch_data() or []` where an empty list is returned on fetch
  failure with no error indication
- `value = config.get("key", "default")` where "default" silently substitutes
  for a missing required key in a critical path

**INVALID finding examples:**
- Optional configurations where a sensible default is genuinely acceptable
  and the calling code is designed to handle either

---

### C06 — return_contracts
**Definition:** A function's return type or documented contract says it
returns a meaningful value, but under error conditions it returns `None`,
`False`, `0`, or an empty collection without raising an exception or setting
an error flag. The caller may not distinguish success from silent failure.

**VALID finding examples:**
- A function documented to return a user object that returns `None` on DB
  error without any indication to the caller
- An API call wrapper that returns `{}` on network failure

**INVALID finding examples:**
- A function that explicitly raises on failure
- Optional-typed return values where `None` is a documented valid state

---

### C13 — confidence_representation
**Definition:** The code returns or logs confidence scores, probabilities, or
certainty values that do not accurately reflect the system's actual epistemic
state — for example, a fixed high confidence value regardless of input quality,
or a confidence score that is never updated to reflect degraded inputs.

**VALID finding examples:**
- `return {"confidence": 0.99, "result": result}` where the confidence is
  hardcoded regardless of processing path
- Logging `"Processing complete with high confidence"` in all branches
  including error recovery paths

**INVALID finding examples:**
- Confidence scores computed from actual model output probabilities
- Confidence values that vary based on input features

---

## How to fill in the rating columns

### `rater1_finding_valid` (required for all rows with findings)

Enter one of:

- **TRUE** — AIRA's finding is correct. The code exhibits the flagged pattern
  and it represents a genuine failure-truthfulness concern in this context.
- **FALSE** — AIRA's finding is incorrect. The code does not exhibit the
  pattern, or the pattern is not a concern in this specific context
  (e.g. a test file where swallowing exceptions is expected).
- **PARTIAL** — The finding has merit but is overstated, or you need more
  context to be certain. Explain in `rater1_notes`.

For **null rows** (where `aira_checks_failed = 0`): leave `rater1_finding_valid`
blank. These rows are for recall assessment only — see below.

### `rater1_missed_finding` (null rows only — optional)

If AIRA found **nothing** in this file but you can see a clear violation of
one of the seven checks above, enter the check id here (e.g. `exception_handling`).
This is how we estimate AIRA's false-negative rate.

Only flag a miss if you are confident: the pattern is unambiguously present
and unambiguously a concern. When in doubt, leave blank.

### `rater1_notes`

Use this for:
- Why you rated something PARTIAL
- Which specific line number or function triggered your judgment
- Context you would need to be more certain
- Any disagreement with AIRA's severity rating (HIGH vs MEDIUM)

---

## Edge cases and judgment calls

**Test files:** Exception suppression in test files is often intentional
(testing that errors are handled gracefully). If the file path or content
makes clear this is a test file and the pattern is test-appropriate, rate FALSE
and note it.

**Intentional logging-only handlers:** `except Exception as e: logger.error(e)`
without re-raise is a genuine grey area. If the logged error will be actioned
by an operator and the system degrades gracefully, PARTIAL is appropriate.
If the system continues as if nothing happened, TRUE is appropriate.

**Framework boilerplate:** Some frameworks generate code that looks like
broad exception suppression but is actually framework-controlled. If you
recognise a standard framework pattern, note it and rate accordingly.

**Uncertainty:** When genuinely uncertain, PARTIAL + notes is always
preferable to a forced TRUE/FALSE call. Kappa calculated on PARTIAL-included
data is more honest than kappa inflated by forced binary choices.

---

## Process

1. Do not communicate with the other rater about specific files until both
   of you have completed all 100 rows.
2. Work in order. Do not cherry-pick easy rows.
3. If you cannot retrieve a file (broken link, private repo), note this in
   `rater1_notes` and leave `rater1_finding_valid` blank. Do not guess.
4. Aim for approximately 2–3 minutes per finding row, 30 seconds per null row.
   Total time estimate: 4–5 hours spread across sessions.
5. When complete, notify the study coordinator. Do not share your sheet
   with Rater 2 until both are done.

---

## Questions

If a check definition is ambiguous for a specific case you encounter, note the
ambiguity in `rater1_notes` and rate PARTIAL. Do not ask the study coordinator
to resolve individual file judgments — that would break blinding. General
definitional questions are fine to ask before you start.
